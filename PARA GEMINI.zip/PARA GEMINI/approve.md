# /approve — Aprobación de TASK

## Propósito

Ejecutar la fase `APPROVED` del workflow del proyecto.

Este comando verifica que una `TASK-XXX` y su propuesta asociada cumplen las condiciones necesarias para pasar de:

```text
PROPOSAL → APPROVED
```

La aprobación debe ser explícita.

Este comando NO implementa cambios de código.

---

## Fuentes obligatorias

Antes de procesar una aprobación, consultar:

1. `AGENTS.md`
2. `docs/00-project/workflow.md`
3. La `TASK-XXX` objetivo.
4. La propuesta correspondiente.
5. Todas las `DEC-XXX` relacionadas.
6. Las TASK de las que dependa.
7. Documentación aplicable cuando sea necesaria para verificar la propuesta.

No crear reglas nuevas dentro de este comando.

---

## Entrada

El comando debe recibir una TASK.

Ejemplo:

```text
/approve TASK-037
```

La TASK debe encontrarse en:

```text
PROPOSAL
```

Si la TASK está en otro estado, no realizar la transición automáticamente.

---

## Principio fundamental

### Verificar no significa aprobar

Gemini puede determinar que una propuesta cumple los requisitos técnicos para ser aprobada.

Sin embargo:

```text
CHECK = verificación
APPROVAL = autorización explícita
```

Una verificación satisfactoria no constituye por sí misma autorización.

---

## Verificación previa

Antes de solicitar o registrar la aprobación, verificar:

### TASK

- Existe.
- El identificador es válido.
- Está en estado `PROPOSAL`.
- Tiene objetivo definido.
- Tiene alcance definido.
- Tiene fuera de alcance definido.
- Tiene criterios de aceptación.
- Tiene plan de implementación.
- Tiene validaciones definidas.

### Propuesta

- Existe.
- Corresponde a la TASK.
- Está basada en un análisis válido.
- Define la solución.
- Define archivos afectados.
- Define dependencias.
- Define riesgos.
- Define impactos.
- Define validación.

### Decisiones

Para cada `DEC-XXX` relacionada:

- Existe.
- Su estado es conocido.
- Su alcance cubre la TASK.
- No existe conflicto con otra decisión aprobada.

Una decisión requerida que todavía no esté aprobada impide la transición.

### Dependencias

Verificar que las TASK requeridas estén:

```text
COMPLETED
```

salvo que la TASK permita explícitamente otro estado.

---

## Resultado de la verificación

Clasificar la verificación como:

```text
READY_FOR_APPROVAL
NOT_READY
BLOCKED
```

### READY_FOR_APPROVAL

Todos los requisitos están satisfechos y la propuesta está lista para aprobación explícita.

### NOT_READY

Falta un requisito que puede resolverse sin una nueva decisión.

Indicar exactamente qué falta.

### BLOCKED

Existe una condición que requiere detener el workflow, por ejemplo:

- decisión pendiente;
- conflicto entre decisiones;
- dependencia bloqueada;
- información esencial ausente;
- inconsistencia de trazabilidad;
- alcance indeterminado.

---

## Solicitud de aprobación

Cuando el resultado sea:

```text
READY_FOR_APPROVAL
```

Gemini debe presentar un resumen para aprobación:

```text
TASK:
Título:

Objetivo:

Alcance:

Fuera de alcance:

Solución propuesta:

Decisiones relacionadas:

Dependencias:

Validaciones:

Riesgos:

Estado:
READY_FOR_APPROVAL
```

Debe esperar una instrucción explícita de aprobación.

Ejemplos válidos:

```text
Aprobado
Apruebo
Approved
Aprobado TASK-037
```

Una respuesta ambigua no debe interpretarse como aprobación.

---

## Aprobación explícita

Cuando el usuario haya aprobado explícitamente:

1. Verificar nuevamente que no hayan cambiado las condiciones relevantes.
2. Confirmar que las DEC requeridas siguen `APPROVED`.
3. Confirmar que las dependencias siguen satisfechas.
4. Registrar la transición:

```text
PROPOSAL → APPROVED
```

5. Mantener la trazabilidad de la TASK.
6. No iniciar `IMPLEMENTATION` automáticamente.

La aprobación autoriza la implementación de **esa TASK y ese alcance**, no de trabajos futuros.

---

## Decisiones pendientes

Si una TASK requiere una `DEC-XXX` que está:

```text
PROPOSED
REJECTED
SUPERSEDED
```

o no existe:

```text
BLOCKED
```

No aprobar la TASK.

La decisión debe resolverse mediante el workflow correspondiente.

---

## Cambios posteriores a la propuesta

Si después de generar la propuesta ocurre cualquiera de estas situaciones:

- cambia el alcance;
- cambia la arquitectura;
- cambia una decisión relacionada;
- cambia un contrato;
- aparece una nueva dependencia relevante;
- cambia significativamente la solución;

la propuesta debe considerarse desactualizada.

Clasificar:

```text
PROPOSAL_OUTDATED
```

y volver a:

```text
ANALYSIS
```

cuando corresponda.

No aprobar una propuesta que ya no representa el trabajo que se pretende realizar.

---

## Trazabilidad

La aprobación debe mantener:

```text
TASK-XXX
   │
   ├── DEC-XXX
   ├── DEC-XXX
   │
   └── PROPOSAL
          │
          ▼
       APPROVED
```

La TASK debe conservar referencias a las decisiones mediante:

```yaml
depends_on_decisions:
  - DEC-XXX
```

Las decisiones deben conservar la referencia inversa:

```yaml
related_tasks:
  - TASK-XXX
```

Si existe inconsistencia:

```text
TRACEABILITY_INCONSISTENCY
```

No ocultarla.

---

## Resultado esperado

El resultado debe utilizar:

```text
# APPROVAL — TASK-XXX

## Resultado

READY_FOR_APPROVAL | NOT_READY | BLOCKED | APPROVED

## Verificaciones

### TASK

- PASS | FAIL

### Propuesta

- PASS | FAIL

### Decisiones

- PASS | FAIL

### Dependencias

- PASS | FAIL

### Trazabilidad

- PASS | FAIL

## Requisitos pendientes

- ...

## Decisiones bloqueantes

- ...

## Aprobación

Estado:
PENDIENTE | APROBADA

Fecha:
YYYY-MM-DD

Aprobador:
<solo si fue explícitamente proporcionado>

## Próximo estado

PROPOSAL
→ APPROVED

o:

PROPOSAL
→ BLOCKED

o:

PROPOSAL
→ REJECTED
```

---

## Registro de aprobación

Cuando el usuario apruebe explícitamente:

- actualizar el estado de la TASK a `APPROVED`;
- conservar la propuesta;
- registrar la fecha;
- registrar identidad del aprobador únicamente si fue proporcionada explícitamente;
- no modificar decisiones aprobadas para forzar la aprobación.

No inventar identidad, fecha ni autorización.

---

## Qué NO hace `/approve`

Este comando NO debe:

- modificar código;
- implementar la TASK;
- ejecutar migraciones;
- instalar dependencias;
- modificar Legacy;
- cambiar contratos;
- crear decisiones y aprobarlas simultáneamente;
- aprobar automáticamente una propuesta;
- aprobar trabajo fuera del alcance;
- iniciar `/implement` automáticamente;
- convertir una recomendación en una decisión normativa sin aprobación.

---

## Regla de parada

Detenerse y marcar:

```text
BLOCKED
```

cuando:

- falta una DEC obligatoria;
- existe conflicto entre decisiones;
- existe una dependencia bloqueante;
- la propuesta está desactualizada;
- el alcance no está definido;
- existe inconsistencia de trazabilidad;
- falta información esencial;
- la aprobación solicitada no es explícita.

No inferir aprobación.

---

## Criterio de finalización

`/approve` finaliza correctamente cuando:

- la TASK fue identificada;
- la propuesta fue verificada;
- las decisiones fueron verificadas;
- las dependencias fueron verificadas;
- la trazabilidad fue verificada;
- la aprobación fue explícita;
- la TASK pasó a `APPROVED`;
- no se realizaron cambios de implementación;
- la siguiente fase queda disponible:

```text
APPROVED → IMPLEMENTATION
```