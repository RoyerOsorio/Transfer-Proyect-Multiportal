# /propose — Propuesta de implementación

## Propósito

Ejecutar la fase `PROPOSAL` del workflow del proyecto.

Este comando transforma un análisis previamente realizado en una propuesta concreta, trazable y evaluable para una `TASK-XXX`.

El objetivo es definir **qué se propone hacer, cómo se propone hacerlo y qué debe aprobarse antes de implementar**.

Este comando NO implementa cambios.

---

## Fuentes obligatorias

Antes de generar la propuesta, consultar:

1. `AGENTS.md`
2. `docs/00-project/workflow.md`
3. La `TASK-XXX` objetivo.
4. El resultado del análisis correspondiente.
5. Todas las `DEC-XXX` relacionadas.
6. Documentación técnica y funcional aplicable.
7. Código actual relevante.
8. Legacy únicamente cuando corresponda.

La jerarquía de fuentes está definida por `AGENTS.md`.

No crear reglas arquitectónicas nuevas dentro de este comando.

---

## Entrada

El comando debe recibir una TASK existente.

Ejemplo:

```text
/propose TASK-037
```

La TASK debe haber pasado previamente por `ANALYSIS`.

Si no existe un análisis suficiente:

```text
BLOCKED
```

No generar una propuesta basada en suposiciones.

---

## Verificación inicial

Antes de generar la propuesta, verificar:

- TASK existente.
- TASK correctamente identificada.
- Análisis disponible.
- Alcance identificado.
- Fuera de alcance identificado.
- Dependencias identificadas.
- Decisiones relacionadas identificadas.
- Riesgos identificados.
- Validaciones requeridas identificadas.

Si alguno de los elementos necesarios no está disponible:

```text
BLOCKED
```

Debe indicarse exactamente qué información falta.

---

## Objetivo de la propuesta

La propuesta debe convertir los hallazgos del análisis en un plan concreto.

Debe responder:

1. ¿Qué problema se resolverá?
2. ¿Qué comportamiento se modificará o agregará?
3. ¿Cómo se propone resolverlo?
4. ¿Qué archivos serán creados o modificados?
5. ¿Qué decisiones existentes aplican?
6. ¿Se requiere una nueva decisión?
7. ¿Qué queda explícitamente fuera del alcance?
8. ¿Cómo se validará?
9. ¿Qué riesgos introduce o mantiene la solución?

---

## Principios de propuesta

La propuesta debe:

- respetar `AGENTS.md`;
- respetar decisiones aprobadas;
- respetar el alcance de la TASK;
- priorizar cambios incrementales;
- evitar refactors innecesarios;
- evitar nuevas dependencias salvo justificación;
- mantener la arquitectura existente cuando sea suficiente;
- separar claramente hechos de propuestas;
- no inventar contratos, endpoints o reglas de negocio;
- preservar el Legacy sin modificarlo.

---

## Evaluación de decisiones

Determinar si la solución:

### No requiere nueva decisión

Cuando la implementación está completamente cubierta por decisiones existentes.

Indicar:

```text
DECISION_REQUIRED: NO
```

### Requiere nueva decisión

Cuando la propuesta implica, por ejemplo:

- cambio arquitectónico;
- nuevo patrón transversal;
- nuevo contrato HTTP;
- modificación de autenticación/autorización;
- cambio de seguridad;
- nueva dependencia relevante;
- cambio de estrategia de estado;
- nuevo componente compartido transversal;
- cambio de límite entre capas;
- modificación significativa de UX;
- cambio de estrategia de migración.

Indicar:

```text
DECISION_REQUIRED: YES
```

y describir la decisión necesaria.

No aprobarla automáticamente.

---

## Nuevas decisiones

Cuando sea necesaria una decisión, proponer un `DEC-XXX`.

La propuesta debe incluir:

```text
DEC-XXX
Título:
Motivo:
Alcance:
Alternativas:
Recomendación:
Impactos:
Riesgos:
Validación:
```

La decisión debe seguir el contrato establecido para:

```text
docs/03-decisions/DEC-XXX.md
```

No crear ni marcar como `APPROVED` una decisión durante `/propose`.

Una decisión nueva requiere aprobación explícita.

---

## Alcance

La propuesta debe definir explícitamente:

### Incluido

Cambios necesarios para cumplir la TASK.

### Excluido

Cambios que no forman parte de la TASK.

No se debe ampliar el alcance simplemente porque durante el análisis se encontraron oportunidades de mejora.

---

## Archivos afectados

Identificar, cuando sea posible:

```text
Crear:
- ...

Modificar:
- ...

Consultar:
- ...

No modificar:
- Legacy/...
```

Si no es posible determinar un archivo con suficiente certeza:

```text
NO DETERMINADO
```

No inventar rutas.

---

## Dependencias

Identificar:

- TASK necesarias;
- DEC necesarias;
- componentes existentes;
- servicios existentes;
- contratos existentes;
- configuración;
- documentación;
- herramientas de validación.

Una dependencia no satisfecha debe impedir la implementación cuando corresponda.

---

## Impactos

Evaluar:

### Arquitectura

Cambios en estructura, responsabilidades o límites.

### Funcional

Cambios observables para el usuario o comportamiento del sistema.

### Visual

Cambios de UI, layout, estilos, responsive o interacción.

### Seguridad

XSS, CSRF/XSRF, autenticación, autorización, datos sensibles, dependencias u otros riesgos relevantes.

### Accesibilidad

Semántica, teclado, foco, contraste, lectores de pantalla y estados accesibles.

### Rendimiento

Carga inicial, renderizado, llamadas HTTP, assets, memoria y otras consideraciones aplicables.

---

## Validación

Definir las validaciones necesarias para la TASK.

Utilizar únicamente las que correspondan:

```text
syntax
build
unit
integration
functional
visual
accessibility
security
regression
e2e
```

Cada validación debe tener un propósito verificable.

---

## Riesgos

Identificar:

- riesgo;
- probabilidad cuando pueda determinarse;
- impacto;
- mitigación;
- condición que lo activa.

No ocultar riesgos para facilitar la aprobación.

---

## Resultado esperado

El resultado debe utilizar la siguiente estructura:

```text
# PROPOSAL — TASK-XXX

## Estado

PROPOSAL

## Objetivo

<objetivo>

## Problema

<problema que se resolverá>

## Análisis de referencia

<resumen de los hallazgos relevantes>

## Solución propuesta

<descripción concreta de la solución>

## Alcance

### Incluido

- ...

### Excluido

- ...

## Archivos afectados

### Crear

- ...

### Modificar

- ...

### Consultar

- ...

### No modificar

- ...

## Decisiones relacionadas

- DEC-XXX — APPROVED
- ...

## Decisiones nuevas requeridas

DECISION_REQUIRED: YES | NO

Si YES:

- DEC-XXX — <título>
- Motivo: ...
- Recomendación: ...

## Dependencias

- ...

## Impactos

### Arquitectura

- ...

### Funcional

- ...

### Visual

- ...

### Seguridad

- ...

### Accesibilidad

- ...

### Rendimiento

- ...

## Riesgos

- ...

## Plan de implementación

1. ...
2. ...
3. ...

## Criterios de aceptación

- [ ] ...
- [ ] ...
- [ ] ...

## Validación

- [ ] build
- [ ] unit
- [ ] functional
- [ ] ...

## Descubrimientos adicionales

- OUT_OF_SCOPE: ...
- TECHNICAL_DEBT: ...
- RISK: ...
- NEW_TASK: ...
- NEW_DECISION: ...
- BLOCKER: ...

## Recomendación

<recomendación final>

## Estado de aprobación

PENDIENTE
```

---

## Regla de aprobación

Toda propuesta generada por `/propose` queda:

```text
PENDIENTE
```

No puede considerarse aprobada por el simple hecho de haber sido generada.

La transición válida es:

```text
PROPOSAL
    ↓
APPROVED
```

mediante aprobación explícita.

---

## Restricciones

Durante `/propose` está prohibido:

- modificar código;
- implementar la solución;
- modificar Legacy;
- instalar dependencias;
- cambiar contratos;
- crear componentes;
- crear servicios;
- ejecutar migraciones;
- aprobar decisiones;
- ampliar el alcance;
- corregir problemas no relacionados.

El comando puede crear o actualizar documentación de propuesta únicamente si el mecanismo de ejecución del proyecto lo permite y la acción está explícitamente autorizada.

La generación de una propuesta no equivale a autorización para modificar el repositorio.

---

## Scope Creep

Si la solución requiere trabajo adicional que no pertenece a la TASK:

No incluirlo silenciosamente.

Clasificarlo como:

```text
OUT_OF_SCOPE
TECHNICAL_DEBT
RISK
NEW_TASK
NEW_DECISION
BLOCKER
```

Cuando corresponda, recomendar una nueva `TASK-XXX`.

---

## Regla de parada

Detenerse y marcar:

```text
BLOCKED
```

cuando:

- el análisis sea insuficiente;
- exista conflicto entre decisiones aprobadas;
- falte información esencial;
- exista una dependencia bloqueante;
- el alcance no pueda determinarse;
- la solución requiera una decisión que todavía no existe;
- exista contradicción entre Current y documentación que requiera decisión;
- la implementación propuesta implique modificar Legacy sin autorización explícita.

No inventar información para continuar.

---

## Criterio de finalización

`/propose` finaliza correctamente cuando:

- existe un análisis válido;
- la solución está definida;
- el alcance está delimitado;
- los archivos afectados están identificados cuando sea posible;
- las dependencias están identificadas;
- las decisiones existentes están verificadas;
- las nuevas decisiones están identificadas;
- los criterios de aceptación están definidos;
- las validaciones están definidas;
- los riesgos están documentados;
- no se realizaron cambios de implementación;
- la propuesta queda lista para aprobación explícita.