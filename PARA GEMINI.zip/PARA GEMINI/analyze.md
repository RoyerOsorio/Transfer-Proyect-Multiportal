# /analyze — Análisis de TASK

## Propósito

Ejecutar la fase `ANALYSIS` del workflow del proyecto.

Este comando permite analizar una TASK de forma estructurada antes de proponer o implementar cambios.

El comando es de **solo lectura**.

NO debe modificar:

- código fuente;
- archivos de configuración;
- documentación;
- `AGENTS.md`;
- decisiones `DEC-XXX`;
- tareas `TASK-XXX`;
- archivos Legacy;
- archivos generados.

---

## Fuentes obligatorias

Antes de iniciar el análisis, consultar:

1. `AGENTS.md`
2. `docs/00-project/workflow.md`
3. La `TASK-XXX` objetivo.
4. Todas las `DEC-XXX` relacionadas con la TASK.
5. Documentación técnica o funcional aplicable.
6. Código actual relevante.
7. Legacy únicamente cuando la TASK requiera comparación o recuperación de comportamiento histórico.

La jerarquía y las reglas de interpretación están definidas en `AGENTS.md` y `docs/00-project/workflow.md`.

No crear reglas nuevas dentro de este comando.

---

## Entrada

El comando debe aceptar una TASK existente como objetivo.

Ejemplo conceptual:

```text
/analyze TASK-037
```

Si no se proporciona TASK:

1. Buscar la TASK activa o indicada por el contexto.
2. Si existe una única TASK claramente identificable, utilizarla.
3. Si existen varias posibilidades, solicitar al usuario que indique cuál analizar.
4. No asumir una TASK arbitrariamente.

---

## Verificación inicial

Antes del análisis, verificar:

- que la TASK existe;
- que su identificador es válido;
- que su contenido puede leerse;
- que sus dependencias están identificadas;
- que las decisiones relacionadas están identificadas;
- que no existe una inconsistencia evidente de trazabilidad.

Si la TASK no existe:

```text
BLOCKED
```

Si existe una inconsistencia que impide realizar un análisis confiable:

```text
BLOCKED
```

No crear automáticamente una TASK o DEC para solucionar el problema.

---

## Alcance del análisis

Determinar:

- objetivo de la TASK;
- alcance incluido;
- alcance excluido;
- feature afectada;
- archivos potencialmente afectados;
- componentes potencialmente afectados;
- servicios o contratos afectados;
- dependencias;
- decisiones relacionadas;
- documentación aplicable;
- impacto arquitectónico;
- impacto funcional;
- impacto visual;
- impacto de seguridad;
- impacto de accesibilidad;
- impacto de rendimiento;
- riesgos;
- validaciones necesarias.

El análisis debe distinguir claramente entre:

```text
CONFIRMADO
PROPUESTO
INFERIDO
NO DETERMINADO
OBSOLETO/DRIFT
```

No convertir inferencias en hechos.

---

## Inspección del código

Inspeccionar únicamente el código relevante para la TASK.

La inspección debe priorizar:

1. Implementación actual.
2. Componentes y servicios relacionados.
3. Contratos HTTP existentes.
4. Modelos y tipos relacionados.
5. Configuración relevante.
6. Tests existentes.
7. Documentación asociada.

No realizar refactors durante la inspección.

No corregir problemas encontrados durante el análisis.

---

## Legacy

Cuando corresponda consultar Legacy:

- utilizarlo como referencia histórica;
- identificar el comportamiento relevante;
- comparar con Current;
- documentar diferencias;
- no modificar Legacy;
- no asumir que Legacy representa automáticamente el comportamiento vigente.

Si Current y Legacy difieren, reportar la diferencia y seguir las reglas de fuente de verdad establecidas por `AGENTS.md`.

---

## Descubrimientos adicionales

Si durante el análisis aparecen problemas no necesarios para completar la TASK, clasificarlos como:

```text
OUT_OF_SCOPE
TECHNICAL_DEBT
RISK
NEW_TASK
NEW_DECISION
BLOCKER
```

No implementarlos.

No ampliar silenciosamente el alcance de la TASK.

---

## Decisiones

Determinar si la TASK requiere:

- una decisión existente;
- una nueva `DEC-XXX`;
- modificación de una decisión existente;
- ninguna decisión adicional.

Si se requiere una nueva decisión:

```text
NEW_DECISION
```

La decisión debe proponerse posteriormente mediante la fase `PROPOSAL`.

No crear ni aprobar automáticamente una `DEC-XXX` durante `/analyze`.

---

## Resultado esperado

El resultado debe tener esta estructura:

```text
# ANALYSIS — TASK-XXX

## Estado

ANALYSIS | BLOCKED

## Objetivo

<objetivo identificado>

## Alcance

### Incluido

- ...

### Excluido

- ...

## Código inspeccionado

- <archivo>
- <archivo>

## Documentación consultada

- <documento>
- <documento>

## Decisiones relacionadas

- DEC-XXX — <estado>
- ...

## Hallazgos

### CONFIRMADO

- ...

### PROPUESTO

- ...

### INFERIDO

- ...

### NO DETERMINADO

- ...

### OBSOLETO/DRIFT

- ...

## Impactos

### Arquitectura

- ...

### Funcional

- ...

### Visual

- ...

### Seguridad

- ...

### Accesibilidad

- ...

### Rendimiento

- ...

## Dependencias

- ...

## Riesgos

- ...

## Validaciones requeridas

- ...

## Descubrimientos adicionales

- OUT_OF_SCOPE: ...
- TECHNICAL_DEBT: ...
- RISK: ...
- NEW_TASK: ...
- NEW_DECISION: ...
- BLOCKER: ...

## Recomendación

<conclusión del análisis y si existe base suficiente para PROPUESTA>
```

---

## Regla de transición

Al finalizar:

### Si existe información suficiente

El resultado queda preparado para:

```text
ANALYSIS → PROPOSAL
```

### Si falta información necesaria

```text
ANALYSIS → BLOCKED
```

Debe especificar exactamente qué información falta.

### Si aparece una decisión necesaria

```text
ANALYSIS → PROPOSAL
```

con `NEW_DECISION` claramente identificado.

---

## Restricciones

Durante `/analyze` está prohibido:

- modificar archivos;
- crear archivos;
- eliminar archivos;
- ejecutar migraciones;
- cambiar dependencias;
- cambiar contratos HTTP;
- modificar Legacy;
- corregir bugs no relacionados;
- realizar refactors;
- instalar paquetes;
- ejecutar acciones destructivas;
- asumir información no disponible.

El análisis debe ser reproducible y trazable.

---

## Criterio de finalización

La fase `ANALYSIS` se considera correctamente ejecutada cuando:

- la TASK fue identificada;
- las fuentes relevantes fueron consultadas;
- el alcance fue determinado;
- el código relevante fue inspeccionado;
- las decisiones fueron verificadas;
- los hallazgos fueron clasificados;
- los riesgos fueron identificados;
- las validaciones fueron identificadas;
- los descubrimientos fuera de alcance fueron clasificados;
- se determinó si puede continuar a `PROPOSAL`;
- no se realizaron modificaciones.