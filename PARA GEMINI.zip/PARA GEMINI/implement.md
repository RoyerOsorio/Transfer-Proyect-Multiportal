# /implement — Implementación de TASK

## Propósito

Ejecutar la fase `IMPLEMENTATION` del workflow del proyecto.

Este comando permite realizar los cambios de código, configuración y documentación estrictamente necesarios para completar una `TASK-XXX` previamente aprobada.

La implementación debe ser:

- incremental;
- trazable;
- limitada al alcance aprobado;
- compatible con las decisiones vigentes;
- validable;
- reversible cuando sea razonablemente posible.

---

## Regla de autorización

`/implement` solamente puede ejecutarse cuando:

```text
TASK-XXX = APPROVED
```

No es suficiente que:

- exista una propuesta;
- el análisis sea satisfactorio;
- Gemini considere correcta la solución;
- el usuario haya indicado previamente una intención general de implementar;
- exista una DEC aprobada.

Debe existir una `TASK-XXX` explícitamente aprobada.

---

## Fuentes obligatorias

Antes de modificar cualquier archivo, consultar:

1. `AGENTS.md`
2. `docs/00-project/workflow.md`
3. `TASK-XXX`
4. La propuesta aprobada.
5. Todas las `DEC-XXX` relacionadas.
6. Dependencias requeridas.
7. Documentación técnica y funcional aplicable.
8. Código actual relevante.
9. Legacy únicamente cuando corresponda.

Estas fuentes determinan los límites de la implementación.

---

## Entrada

El comando debe recibir una TASK aprobada.

Ejemplo:

```text
/implement TASK-037
```

Si no se proporciona TASK:

- identificar una TASK inequívocamente aprobada solamente si el contexto lo permite;
- si existen varias TASK aprobadas, solicitar identificación;
- no seleccionar arbitrariamente una TASK.

---

## Verificación previa

Antes de modificar el repositorio verificar:

### TASK

- Existe.
- Está en estado `APPROVED`.
- Tiene alcance definido.
- Tiene fuera de alcance definido.
- Tiene criterios de aceptación.
- Tiene plan de implementación.
- Tiene validaciones requeridas.

### DEC

Todas las decisiones requeridas:

- existen;
- están `APPROVED`;
- cubren el alcance;
- no están `SUPERSEDED`;
- no presentan conflicto.

### Dependencias

Las dependencias requeridas están satisfechas según la TASK.

### Estado del repositorio

Inspeccionar el estado actual antes de comenzar.

Identificar:

- cambios existentes;
- archivos modificados previamente;
- trabajo no relacionado;
- posibles conflictos con los archivos que deben modificarse.

No sobrescribir cambios ajenos.

---

## Protección contra cambios no relacionados

Antes de implementar, determinar qué archivos pueden ser modificados según:

```text
TASK.scope
TASK.files
DEC-XXX
```

Si aparece la necesidad de modificar un archivo no contemplado:

1. Determinar si el cambio es estrictamente necesario para la TASK.
2. Si es necesario y está claramente dentro del alcance, documentarlo.
3. Si requiere una decisión nueva, detenerse.
4. Si no es necesario, clasificarlo como `OUT_OF_SCOPE` o `NEW_TASK`.

No ampliar silenciosamente la TASK.

---

## Inicio de implementación

Una vez satisfechas las verificaciones:

```text
APPROVED
   ↓
IMPLEMENTATION
```

Registrar el inicio de la implementación.

A partir de este punto se pueden modificar únicamente los elementos autorizados.

---

## Principios de implementación

Durante la implementación:

- seguir exactamente la propuesta aprobada;
- respetar `AGENTS.md`;
- respetar las `DEC-XXX`;
- preservar la arquitectura vigente;
- realizar cambios mínimos necesarios;
- evitar refactors no relacionados;
- evitar cambios cosméticos no solicitados;
- evitar introducir abstracciones prematuras;
- reutilizar patrones existentes cuando sean apropiados;
- no inventar contratos;
- no inventar reglas de negocio;
- no modificar Legacy;
- no introducir dependencias sin autorización.

---

## Angular

Cuando la TASK corresponda a Angular:

- respetar las decisiones arquitectónicas aprobadas;
- utilizar patrones compatibles con Angular 22;
- mantener standalone cuando corresponda;
- respetar la estrategia de estado definida;
- respetar contratos HTTP existentes;
- mantener tipado adecuado;
- utilizar formularios tipados cuando corresponda;
- preservar accesibilidad;
- evitar lógica de negocio innecesaria en componentes;
- evitar componentes o servicios "God Object";
- evitar duplicación injustificada;
- no introducir librerías para resolver problemas que puedan resolverse con las capacidades existentes y aprobadas.

La implementación concreta debe derivarse de las decisiones aprobadas y del código actual, no de reglas nuevas creadas dentro de este comando.

---

## Backend / HTTP

Si la TASK afecta comunicación HTTP:

- respetar el contrato aprobado;
- no inventar endpoints;
- no cambiar verbos HTTP arbitrariamente;
- no cambiar payloads sin aprobación;
- respetar autenticación;
- respetar autorización;
- respetar CSRF/XSRF;
- respetar manejo de errores;
- no introducir BFF, API Gateway o microservicios salvo aprobación explícita;
- no modificar contratos de API como efecto secundario.

Un cambio de contrato que no esté cubierto por una DEC aprobada requiere detenerse.

---

## Seguridad

No introducir:

- secretos en frontend;
- credenciales;
- tokens expuestos innecesariamente;
- HTML dinámico inseguro;
- bypass de autenticación;
- bypass de autorización;
- desactivación de protecciones CSRF/XSRF;
- logging de información sensible;
- dependencias inseguras sin evaluación.

Si la implementación revela un riesgo de seguridad fuera del alcance:

```text
RISK
```

y reportarlo sin realizar cambios no autorizados.

Si corregirlo es necesario para completar la TASK, detenerse si requiere una nueva decisión.

---

## Formularios

Cuando corresponda:

- mantener estado de validación coherente;
- no depender únicamente de validación visual;
- mantener accesibilidad;
- evitar doble envío;
- representar errores de backend;
- mantener estados de carga;
- preservar las reglas funcionales aprobadas.

Los botones deben reflejar el estado real del formulario y de la operación.

---

## UI / Diseño

La implementación debe preservar:

- diseño aprobado;
- tokens existentes;
- responsive;
- comportamiento funcional;
- estados interactivos;
- accesibilidad.

No rediseñar componentes por preferencia personal.

Una mejora visual descubierta durante la implementación debe clasificarse como:

```text
OUT_OF_SCOPE
TECHNICAL_DEBT
NEW_TASK
```

según corresponda.

---

## Cambios de archivos

Para cada archivo modificado, el agente debe poder explicar:

```text
Archivo:
Motivo:
Relación con TASK:
Relación con DEC:
```

No modificar archivos solamente porque sean cercanos o convenientes.

---

## Dependencias

No instalar, actualizar o eliminar dependencias durante la implementación salvo que:

1. estén explícitamente contempladas en la TASK/DEC; o
2. exista una autorización adicional explícita y se actualice la trazabilidad correspondiente.

Si una dependencia resulta necesaria pero no está aprobada:

```text
BLOCKED
```

---

## Descubrimientos durante la implementación

Si se descubre un problema adicional:

### No necesario para la TASK

Clasificar como:

```text
OUT_OF_SCOPE
TECHNICAL_DEBT
RISK
NEW_TASK
```

y continuar únicamente si no afecta la implementación aprobada.

### Necesario para completar la TASK y cubierto por las decisiones

Implementar si permanece dentro del alcance aprobado.

### Necesario pero requiere nueva decisión

Detener la implementación:

```text
IMPLEMENTATION → BLOCKED
```

y reportar:

- problema;
- motivo por el que es necesario;
- decisión requerida;
- impacto;
- alternativas.

No improvisar una solución arquitectónica.

---

## Cambios irreversibles

Antes de realizar acciones potencialmente destructivas:

- confirmar que están explícitamente autorizadas;
- preservar información cuando sea posible;
- evitar eliminar trabajo ajeno;
- evitar comandos destructivos;
- no reescribir historial Git;
- no realizar acciones irreversibles innecesarias.

---

## Git

Respetar el estado existente del repositorio.

No:

- ejecutar `reset --hard`;
- eliminar cambios ajenos;
- reescribir historial;
- modificar commits existentes;
- hacer force push;
- borrar ramas;
- limpiar archivos no relacionados;

salvo autorización explícita fuera del alcance normal de esta TASK.

No asumir que un repositorio limpio es requisito si la TASK no lo establece.

---

## Ejecución incremental

Cuando una TASK tenga varios pasos:

1. Implementar un cambio pequeño.
2. Revisar el resultado.
3. Continuar con el siguiente cambio.
4. Evitar acumular cambios innecesarios.
5. Mantener trazabilidad.

Si una etapa revela un problema que invalida la propuesta, detenerse antes de continuar.

---

## Validación durante implementación

La implementación puede ejecutar validaciones técnicas intermedias, por ejemplo:

```text
type-check
lint
unit test específico
build parcial
```

Estas validaciones no sustituyen la fase formal:

```text
VALIDATION
```

Su finalidad es detectar errores temprano.

---

## Estado de implementación

Durante la ejecución:

```text
APPROVED
   ↓
IMPLEMENTATION
```

Si finaliza correctamente:

```text
IMPLEMENTATION
   ↓
VALIDATION
```

Si existe un bloqueo:

```text
IMPLEMENTATION
   ↓
BLOCKED
```

No marcar `COMPLETED` desde `/implement`.

---

## Resultado esperado

El resultado debe utilizar:

```text
# IMPLEMENTATION — TASK-XXX

## Estado

IMPLEMENTATION | VALIDATION | BLOCKED

## Objetivo

<objetivo>

## Decisiones utilizadas

- DEC-XXX
- DEC-XXX

## Cambios realizados

### Archivos creados

- ...

### Archivos modificados

- ...

### Archivos eliminados

- ...

Si no hubo archivos eliminados:

- Ninguno

## Resumen de implementación

<descripción breve y técnica>

## Criterios de aceptación

- [ ] Criterio 1
- [ ] Criterio 2
- [ ] ...

## Validaciones preliminares

- type-check: PASS | FAIL | NOT_RUN
- lint: PASS | FAIL | NOT_RUN
- test: PASS | FAIL | NOT_RUN
- build: PASS | FAIL | NOT_RUN

## Descubrimientos

- ...

## Riesgos

- ...

## Bloqueos

- ...

## Próximo estado

VALIDATION

o:

BLOCKED
```

---

## Regla de no finalización

`/implement` NO debe marcar una TASK como:

```text
COMPLETED
```

La implementación solamente prepara la TASK para:

```text
VALIDATION
```

La finalización requiere la ejecución satisfactoria de las validaciones correspondientes y el reporte final.

---

## Regla de parada

Detener inmediatamente la implementación cuando:

- la TASK no está `APPROVED`;
- una DEC requerida no está `APPROVED`;
- una DEC aplicable está `SUPERSEDED`;
- existe conflicto entre decisiones;
- falta una dependencia bloqueante;
- el alcance resulta insuficiente;
- se requiere modificar Legacy;
- se requiere cambiar arquitectura no aprobada;
- se requiere cambiar un contrato no aprobado;
- se necesita una dependencia no aprobada;
- aparece una decisión arquitectónica nueva;
- el cambio puede comprometer seguridad y no está cubierto;
- el agente no puede determinar de forma confiable el comportamiento requerido.

En estos casos:

```text
IMPLEMENTATION → BLOCKED
```

y explicar exactamente el motivo.

---

## Criterio de finalización

La fase `IMPLEMENTATION` finaliza correctamente cuando:

- la TASK estaba `APPROVED`;
- las decisiones aplicables estaban aprobadas;
- las dependencias fueron verificadas;
- solamente se realizaron cambios autorizados;
- no se modificó Legacy;
- no hubo scope creep no clasificado;
- los criterios de aceptación están listos para validación;
- las validaciones preliminares fueron ejecutadas cuando correspondía;
- los cambios están documentados;
- la TASK queda preparada para:

```text
VALIDATION
```

La validación formal y el reporte final deben ejecutarse mediante sus comandos correspondientes.