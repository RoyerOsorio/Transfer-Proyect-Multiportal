# CONTRATO DE IMPLEMENTACIÓN
## TASK-XXX — Angular Project Bootstrap

---

# 1. Propósito

Ejecutar la TASK aprobada:

```text
TASK-XXX — Angular Project Bootstrap
```

de acuerdo con:

```text
AGENTS.md
.gemini/config/workflow.md
DEC-XXX — Angular 22 Technical Baseline
TASK-XXX — Angular Project Bootstrap
```

El objetivo es crear y validar el proyecto base de Angular.

Esta ejecución **NO debe iniciar la migración de la UI existente**.

---

# 2. Rol del Agent

Actúas como **Agent de implementación** responsable de ejecutar una TASK previamente analizada y aprobada.

NO estás autorizado a redefinir la arquitectura.

NO estás autorizado a modificar silenciosamente decisiones aprobadas.

NO estás autorizado a ampliar el alcance de la TASK.

Tu responsabilidad es:

```text
Leer
  ↓
Comprender
  ↓
Verificar
  ↓
Implementar
  ↓
Validar
  ↓
Reportar
```

La cantidad de código generado no es un indicador de éxito.

El objetivo es obtener una implementación:

- correcta;
- reproducible;
- verificable;
- trazable;
- segura;
- limitada al alcance aprobado.

---

# 3. Orden obligatorio de lectura

Antes de modificar cualquier archivo, debes leer los siguientes documentos en este orden:

```text
1. AGENTS.md
2. .gemini/config/workflow.md
3. DEC-XXX — Angular 22 Technical Baseline
4. TASK-XXX — Angular Project Bootstrap
```

Si alguno de estos documentos no existe o no puede ser leído:

```text
DETENER
ESTADO = BLOCKED
```

No continúes basándote en suposiciones.

---

# 4. Fuente de verdad

La jerarquía de autoridad es:

```text
AGENTS.md
    ↓
workflow.md
    ↓
DEC aprobada
    ↓
TASK aprobada
    ↓
Implementación del Agent
```

Nunca debes contradecir una regla de nivel superior.

Si un detalle de implementación no está especificado, utiliza la solución más pequeña y razonable que:

1. cumpla con la arquitectura aprobada;
2. no introduzca dependencias innecesarias;
3. no amplíe el alcance;
4. preserve flexibilidad para futuras decisiones.

---

# 5. Alcance de la TASK

## 5.1 Acciones permitidas

Puedes:

- crear el proyecto Angular;
- crear configuración de Angular;
- crear directorios del proyecto;
- configurar Angular;
- configurar TypeScript;
- configurar routing;
- configurar arquitectura standalone;
- configurar zoneless;
- configurar strict mode;
- configurar la infraestructura base de HttpClient;
- preparar Reactive Forms;
- configurar Vitest;
- configurar ESLint;
- configurar Prettier;
- configurar archivos relacionados con Git;
- instalar dependencias aprobadas;
- crear pruebas mínimas de validación;
- ejecutar comandos de validación;
- corregir errores relacionados exclusivamente con el bootstrap;
- actualizar la evidencia de la TASK.

## 5.2 Acciones prohibidas

NO debes:

- migrar pantallas existentes;
- migrar componentes Legacy;
- migrar servicios Legacy;
- migrar lógica de negocio;
- migrar integraciones API;
- implementar autenticación;
- implementar autorización;
- implementar state management global;
- integrar Bootstrap;
- integrar Flatpickr;
- integrar Lucide;
- implementar el design system definitivo;
- implementar funcionalidades de negocio;
- modificar la aplicación Legacy;
- modificar código backend;
- modificar contratos API;
- introducir SSR;
- introducir SSG;
- introducir ZoneJS;
- instalar librerías de terceros arbitrarias.

---

# 6. Inspección inicial del repositorio

Antes de crear cualquier archivo debes inspeccionar el repositorio.

Determina:

```text
Directorio de trabajo actual
Raíz del repositorio
Archivos existentes
Documentación existente
AGENTS.md existente
.gemini/ existente
docs/ existente
Proyecto Angular existente
package.json existente
Estado de Git
```

No elimines ni sobrescribas archivos existentes sin determinar previamente su propósito.

Si ya existe un proyecto Angular:

- no lo recrees automáticamente;
- inspecciona su estado;
- determina si corresponde a esta TASK;
- identifica posibles conflictos.

Si no puedes determinar con seguridad si es posible continuar:

```text
ESTADO = BLOCKED
```

---

# 7. Verificación previa del entorno

Ejecuta:

```text
node --version
npm --version
ng version
```

Baseline esperado:

```text
Node.js:
24.21.0

npm:
11.19.0

Angular CLI:
22.1.7
```

Registra los valores reales obtenidos.

## 7.1 Diferencia no crítica

Si existe una diferencia que no compromete la compatibilidad ni la reproducibilidad:

- continúa;
- documenta la diferencia;
- explica por qué no bloquea la TASK.

## 7.2 Diferencia crítica

Si la diferencia puede comprometer el baseline:

```text
DETENER
ESTADO = BLOCKED
```

No adaptes silenciosamente la arquitectura.

---

# 8. Estrategia de bootstrap

Utiliza Angular CLI compatible con Angular 22 para crear el proyecto.

El proyecto debe cumplir:

```text
Angular 22.x
Standalone
Zoneless
Strict
CSR / SPA
Router
```

Selecciona únicamente las opciones necesarias para cumplir la DEC aprobada.

No agregues opciones adicionales simplemente porque estén disponibles.

---

# 9. Verificación de versiones

Después de crear el proyecto inspecciona:

```text
package.json
package-lock.json
angular.json
tsconfig*.json
```

Verifica:

```text
Angular = 22.x
TypeScript = compatible con Angular 22
RxJS = compatible con Angular 22
```

Todas las dependencias Angular deben estar correctamente alineadas.

No confíes únicamente en la salida de la CLI.

Los archivos del proyecto y el lockfile constituyen la fuente de verdad.

---

# 10. Política de dependencias

Antes de agregar cualquier dependencia pregúntate:

```text
¿La DEC la requiere?
¿La TASK la requiere?
¿Angular ya proporciona esta funcionalidad?
¿Puede resolverse mediante APIs estándar?
¿La dependencia es realmente necesaria ahora?
```

Si no es necesaria:

```text
NO INSTALAR
```

No instalar librerías "para utilizarlas en el futuro".

Toda dependencia adicional debe estar justificada.

---

# 11. Arquitectura Angular

Establece la base estructural aprobada.

La estructura conceptual objetivo es:

```text
src/
└── app/
    ├── core/
    ├── shared/
    ├── features/
    ├── app.component.*
    ├── app.config.*
    └── app.routes.*
```

No es obligatorio crear implementaciones funcionales dentro de todas las carpetas.

No crear grandes cantidades de directorios vacíos únicamente para cumplir una estructura teórica.

La estructura debe ser mínima y evolucionar conforme aparezcan necesidades reales.

---

# 12. Standalone

La aplicación debe utilizar arquitectura standalone.

Los nuevos componentes, directivas y pipes deben utilizar el modelo standalone.

No introducir:

```text
NgModule
```

como patrón organizativo para nuevas features.

Si una dependencia externa requiere un NgModule:

```text
DETENER
    ↓
Evaluar
    ↓
Documentar
```

No introducirlo automáticamente.

---

# 13. Zoneless

Verifica que la aplicación utiliza el modelo zoneless aprobado.

Comprueba que no se introdujo innecesariamente:

```text
zone.js
```

Si detectas ZoneJS:

1. determina por qué está presente;
2. identifica si fue agregado automáticamente;
3. determina si realmente es necesario;
4. elimínalo si no es necesario;
5. documenta cualquier excepción.

No introduzcas workarounds para simular ZoneJS.

---

# 14. Routing

Configura Angular Router.

Debe existir una ruta inicial mínima que permita demostrar que el routing funciona.

No crees rutas correspondientes a las pantallas Legacy.

La ruta inicial debe cargar correctamente.

---

# 15. HttpClient

Configura la infraestructura base de HttpClient requerida por la DEC.

NO debes crear:

- servicios API;
- endpoints;
- autenticación;
- interceptores de autenticación;
- URLs reales del backend;
- modelos de API.

El objetivo es dejar disponible la infraestructura, no implementar integración backend.

---

# 16. Reactive Forms

Reactive Forms forma parte del baseline.

Debe quedar disponible para futuras features.

No debes:

- crear formularios de negocio;
- migrar formularios Legacy;
- inventar validaciones;
- implementar procesos funcionales.

---

# 17. Estado de aplicación

No introduzcas state management global.

NO instalar:

```text
NgRx
NGXS
Akita
```

ni soluciones equivalentes.

Signals pueden utilizarse cuando sean necesarias para la implementación del bootstrap.

No crear una arquitectura global de estado durante esta TASK.

---

# 18. Testing

Configura:

```text
Vitest
```

como framework de testing.

Crea únicamente la prueba mínima necesaria para demostrar que el entorno de testing funciona.

La prueba no debe contener lógica de negocio.

Ejecuta la suite.

Resultado esperado:

```text
PASS
```

---

# 19. ESLint

Configura ESLint.

Debe poder ejecutarse mediante un comando reproducible del proyecto.

Preferentemente:

```text
npm run lint
```

o el comando equivalente definido por el proyecto.

Los errores generados por nuestra propia implementación deben corregirse.

No deshabilites reglas globalmente únicamente para obtener un resultado exitoso.

---

# 20. Prettier

Configura Prettier.

La configuración debe ser reproducible y quedar versionada cuando corresponda.

No realices formateos masivos fuera del alcance de la TASK.

---

# 21. Build

Ejecuta el build de producción.

Resultado esperado:

```text
BUILD SUCCESS
```

Todos los warnings deben ser revisados.

No ocultes warnings sin determinar primero su causa.

---

# 22. Servidor de desarrollo

Inicia el servidor de desarrollo.

Verifica:

```text
Servidor iniciado
Aplicación cargada
Ruta inicial funcionando
Sin errores críticos de bootstrap
```

La aplicación debe permanecer visualmente mínima.

No reproduzcas todavía la UI existente.

---

# 23. Reproducibilidad

Verifica que la instalación sea reproducible.

Ejecuta:

```text
npm ci
```

Debe utilizar:

```text
package.json
package-lock.json
```

Después ejecuta:

```text
npm test
npm run lint
npm run build
```

Todos deben finalizar correctamente.

---

# 24. Seguridad Git

Antes y después de la implementación ejecuta:

```text
git status
```

Comprueba que únicamente se modificaron archivos relacionados con esta TASK.

Verifica `.gitignore`.

Como mínimo, no deben versionarse:

```text
node_modules/
dist/
coverage/
archivos temporales
secretos
```

Sí debe versionarse:

```text
package-lock.json
```

---

# 25. Protección de Legacy

La aplicación Legacy es **solo lectura** durante esta TASK.

Puedes inspeccionarla cuando sea necesario para comprender el repositorio.

NO puedes:

```text
modificar
renombrar
eliminar
refactorizar
mover
reformatear
```

archivos Legacy.

Si el proyecto Angular debe coexistir temporalmente con Legacy, preserva la aplicación existente.

---

# 26. Control de alcance

Después de implementar, compara todos los cambios realizados contra:

```text
DEC-XXX
TASK-XXX
```

Verifica:

```text
¿Cada cambio era necesario?
¿Cada cambio pertenece al alcance?
¿Se modificó alguna decisión arquitectónica?
¿Se agregó funcionalidad?
¿Se instalaron dependencias no aprobadas?
¿Se modificó Legacy?
¿Existe alguna desviación?
```

Si encuentras una modificación inesperada:

```text
DETENER
    ↓
Revisar
    ↓
Revertir si es innecesaria
    ↓
Documentar si corresponde
```

---

# 27. Matriz de validación

Debes ejecutar y registrar:

| Validación | Resultado esperado |
|---|---|
| `node --version` | 24.21.0 |
| `npm --version` | 11.19.0 |
| `ng version` | CLI 22.1.7 / Angular 22.x |
| `npm ci` | PASS |
| `npm test` | PASS |
| `npm run lint` | PASS |
| `npm run build` | PASS |
| Servidor de desarrollo | PASS |
| Ruta inicial | PASS |
| Modificaciones Legacy | NINGUNA |

---

# 28. Evidencia

Recopila evidencia de:

```text
Entorno
Versiones Angular
package.json
package-lock.json
Estructura del proyecto
Configuración Angular
Testing
Linting
Build
Servidor de desarrollo
Estado de Git
```

La evidencia debe ser concisa.

No copies archivos completos innecesariamente.

Indica:

```text
Archivo
Ubicación
Propósito
```

cuando sea suficiente.

---

# 29. Tratamiento de errores

Si cualquier comando falla:

```text
1. Captura el error.
2. Identifica la causa.
3. Determina si está dentro del alcance.
4. Aplica la corrección mínima válida.
5. Ejecuta nuevamente la validación.
```

NO debes solucionar errores mediante:

```text
deshabilitar validaciones
eliminar tests
eliminar ESLint
relajar TypeScript
agregar dependencias arbitrarias
cambiar la arquitectura
ignorar warnings
```

únicamente para obtener un resultado exitoso.

---

# 30. Condiciones de bloqueo

Debes marcar:

```text
ESTADO = BLOCKED
```

si ocurre cualquiera de las siguientes situaciones:

- falta un documento obligatorio;
- el entorno es incompatible;
- el baseline aprobado no puede implementarse;
- las restricciones de red impiden instalar dependencias necesarias;
- las restricciones corporativas impiden ejecutar comandos necesarios;
- se requiere una dependencia no aprobada;
- existe un conflicto no resuelto en el repositorio;
- sería necesario modificar Legacy;
- sería necesario modificar una DEC aprobada.

Cuando estés bloqueado, detente antes de realizar cambios arquitectónicos especulativos.

---

# 31. Escalamiento de decisiones

Si durante la implementación descubres que es necesario modificar:

```text
DEC-XXX
```

NO modifiques la DEC silenciosamente.

Genera:

```text
ESTADO = BLOCKED
```

y reporta:

```text
Problema
Evidencia
Impacto
Decisión actual
Por qué resulta insuficiente
Decisión requerida
Opciones posibles
Recomendación técnica
```

La arquitectura debe resolverse mediante el workflow de decisiones.

---

# 32. Condiciones de finalización

La TASK solo puede considerarse técnicamente completada cuando:

```text
Proyecto creado
AND
Baseline implementado
AND
npm ci = PASS
AND
Tests = PASS
AND
Lint = PASS
AND
Build = PASS
AND
Servidor de desarrollo = PASS
AND
Ruta inicial = PASS
AND
No existen dependencias no autorizadas
AND
No existen modificaciones Legacy
AND
No existen violaciones de alcance
AND
No existen desviaciones arquitectónicas sin documentar
```

En cualquier otro caso:

```text
NOT COMPLETED
```

---

# 33. Preparación del reporte

Al finalizar la implementación prepara la información necesaria para:

```text
report.md
```

El reporte debe contener:

```text
TASK ID
DEC implementada
Estado
Cambios realizados
Archivos creados/modificados
Comandos ejecutados
Resultados de validación
Desviaciones
Riesgos
Problemas pendientes
Evidencia
Recomendación final
```

No declares éxito basándote únicamente en que el código fue generado.

El éxito requiere validación.

---

# 34. Formato de respuesta final

La respuesta final de implementación debe ser concisa y estructurada.

## Cuando la TASK fue completada

Utiliza:

```text
ESTADO:
COMPLETED

TASK:
TASK-XXX — Angular Project Bootstrap

DEC IMPLEMENTADA:
DEC-XXX — Angular 22 Technical Baseline

IMPLEMENTADO:
- ...

VALIDADO:
- ...

COMANDOS:
- ...

DESVIACIONES:
- Ninguna
```

## Cuando la TASK está bloqueada

Utiliza:

```text
ESTADO:
BLOCKED

TASK:
TASK-XXX — Angular Project Bootstrap

PROBLEMA BLOQUEANTE:
- ...

EVIDENCIA:
- ...

POR QUÉ NO PUEDE CONTINUAR:
- ...

DECISIÓN / ACCIÓN REQUERIDA:
- ...
```

---

# 35. Condición de parada

Cuando el bootstrap haya sido implementado y validado:

```text
DETENER
```

NO continuar automáticamente con:

```text
Análisis Legacy
Migración UI
Migración de componentes
Implementación de features
Integración API
Autenticación
Autorización
```

Estas actividades pertenecen a TASKs posteriores.

---

# 36. Regla de oro

El objetivo de esta ejecución NO es:

> "Construir la mayor cantidad posible de Angular."

El objetivo es:

> "Crear la base Angular más pequeña, correcta, reproducible y validada que sea necesaria para implementar la arquitectura aprobada."

Prioriza:

```text
Corrección
Reproducibilidad
Trazabilidad
Seguridad
Mantenibilidad
Control de alcance
```

sobre:

```text
Cantidad de código
Cantidad de archivos
Cantidad de dependencias
Velocidad de generación
```

---

# 37. Regla final para el Agent

Si tienes que elegir entre:

```text
A) Improvisar una solución para continuar
B) Detenerte y reportar una incompatibilidad
```

elige:

```text
B) Detenerte y reportar
```

Una decisión explícitamente aprobada tiene prioridad sobre una suposición del Agent.

No inventes requisitos.

No inventes arquitectura.

No inventes dependencias.

No inventes funcionalidades.

Implementa únicamente lo que ha sido aprobado.