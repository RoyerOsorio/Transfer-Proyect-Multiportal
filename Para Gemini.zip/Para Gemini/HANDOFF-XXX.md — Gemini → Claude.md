# HANDOFF-XXX
## Transferencia de implementación — Gemini → Claude

---

# 1. Identificación

| Campo | Valor |
|---|---|
| Handoff ID | HANDOFF-XXX |
| TASK ID | TASK-XXX |
| DEC ID | DEC-XXX |
| Proyecto | [Nombre del proyecto] |
| Rama | [Rama de trabajo] |
| Fecha | [YYYY-MM-DD] |
| Generado por | Gemini |
| Implementado por | Claude |
| Estado | DRAFT / APPROVED / IN_PROGRESS / COMPLETED / BLOCKED |

---

# 2. Propósito

Este documento constituye el contrato de transferencia entre la fase de análisis/planificación y la fase de implementación.

Su objetivo es proporcionar a Claude toda la información necesaria para ejecutar la TASK aprobada sin depender de información almacenada únicamente en una conversación de Gemini.

La fuente de verdad continúa siendo:

```text
AGENTS.md
    ↓
workflow.md
    ↓
DEC-XXX
    ↓
TASK-XXX
    ↓
HANDOFF-XXX
```

El HANDOFF no puede contradecir ninguno de los documentos anteriores.

Si existe una contradicción:

```text
DETENER
ESTADO = BLOCKED
```

---

# 3. Documentos de referencia

Claude debe leer y considerar obligatoriamente:

```text
AGENTS.md

.gemini/config/workflow.md

DEC-XXX

TASK-XXX

HANDOFF-XXX
```

Si la estructura del proyecto utiliza una ubicación diferente para alguno de estos documentos, utilizar la ubicación establecida por el repositorio.

El HANDOFF nunca reemplaza a la DEC ni a la TASK.

---

# 4. Contexto de la TASK

## Problema

[Descripción concreta del problema que la TASK pretende resolver.]

## Objetivo

[Resultado que debe obtenerse.]

## Motivación

[Por qué se realiza esta TASK.]

## Resultado esperado

[Descripción verificable del estado final.]

---

# 5. Alcance aprobado

## Incluido

- [Elemento]
- [Elemento]
- [Elemento]

## Excluido

- [Elemento]
- [Elemento]
- [Elemento]

Claude debe respetar estrictamente esta delimitación.

No debe interpretar "excluido" como una recomendación.

Es una restricción.

---

# 6. Decisiones arquitectónicas aplicables

Relacionar explícitamente las decisiones que afectan a la implementación.

| DEC | Decisión | Impacto |
|---|---|---|
| DEC-XXX | [Decisión] | [Cómo afecta] |

Si existe una decisión relevante que no está contemplada:

```text
NO asumir
NO improvisar
NO modificar la DEC
```

Debe reportarse como posible bloqueo.

---

# 7. Estado actual del proyecto

Registrar el estado conocido antes de comenzar:

```text
Framework:
Angular XX

Node:
XX

npm:
XX

Testing:
[Framework]

Linting:
[Herramienta]

Build:
[Herramienta]

Estado del repositorio:
[Descripción]
```

## Estructura relevante

```text
src/
├── ...
├── ...
└── ...
```

Esta sección debe contener únicamente información relevante para la TASK.

---

# 8. Resultado del análisis de Gemini

## Hallazgos

- [Hallazgo]
- [Hallazgo]
- [Hallazgo]

## Riesgos identificados

- [Riesgo]
- [Riesgo]

## Restricciones técnicas

- [Restricción]
- [Restricción]

## Suposiciones

Toda suposición debe estar explícitamente identificada.

```text
SUP-001:
[Descripción]
```

Una suposición NO debe tratarse como una decisión aprobada.

---

# 9. Plan de implementación

Claude debe utilizar esta sección como guía principal de implementación.

## Fase 1 — Preparación

- [Acción]
- [Acción]

## Fase 2 — Implementación

- [Acción]
- [Acción]

## Fase 3 — Integración

- [Acción]
- [Acción]

## Fase 4 — Validación

- [Acción]
- [Acción]

Claude debe ejecutar las fases en orden salvo que exista una razón técnica documentada para alterar el orden.

---

# 10. Archivos esperados

## Crear

```text
[archivo]
[archivo]
[archivo]
```

## Modificar

```text
[archivo]
[archivo]
```

## No modificar

```text
[archivo]
[directorio]
Legacy/*
```

Los archivos esperados son una guía de alcance.

Si durante la implementación resulta necesario crear o modificar un archivo adicional, Claude debe justificarlo.

---

# 11. Componentes y responsabilidades

Cuando aplique, especificar los componentes involucrados.

| Componente | Responsabilidad | Ubicación |
|---|---|---|
| [Componente] | [Responsabilidad] | [Ruta] |

## Reglas

Cada componente debe tener una responsabilidad clara.

Evitar componentes monolíticos.

Evitar duplicación.

Evitar introducir lógica de negocio en componentes cuando corresponda a otra capa.

---

# 12. Servicios y responsabilidades

Cuando aplique:

| Servicio | Responsabilidad | Ubicación |
|---|---|---|
| [Servicio] | [Responsabilidad] | [Ruta] |

Los servicios deben mantener una responsabilidad específica.

No crear servicios únicamente como contenedores genéricos de lógica.

---

# 13. Modelos y contratos

Cuando aplique:

```text
Interfaces:
[...]
Types:
[...]
Enums:
[...]
DTOs:
[...]
```

No modificar contratos existentes sin autorización.

No inventar contratos backend.

---

# 14. Routing

Cuando aplique:

```text
Ruta:
[...]
Componente:
[...]
Lazy loading:
[...]
Guards:
[...]
```

No agregar rutas que no formen parte de la TASK.

---

# 15. Manejo HTTP

Cuando aplique, especificar:

```text
HttpClient
Interceptors
Error handling
Request handling
Retry policy
Timeouts
API contracts
```

No inventar endpoints.

No inventar respuestas del backend.

Si la TASK requiere información que no está disponible:

```text
ESTADO = BLOCKED
```

---

# 16. Manejo de errores

Definir:

```text
Error esperado:
[...]
Error técnico:
[...]
Error de red:
[...]
Error de validación:
[...]
Error desconocido:
[...]
```

Indicar dónde debe resolverse cada categoría.

No utilizar:

```text
catch
```

como mecanismo genérico para ocultar errores.

Los errores deben conservar suficiente contexto para diagnóstico.

---

# 17. Seguridad

Requisitos de seguridad aplicables:

- [Requisito]
- [Requisito]

Claude debe considerar como mínimo:

```text
Validación de entrada
Manejo de errores
Exposición de información
Secretos
Credenciales
URLs sensibles
Datos personales
Logs
Dependencias
```

No introducir secretos en:

```text
Código fuente
Archivos versionados
Logs
Variables públicas
```

Si una implementación requiere información sensible que no está disponible:

```text
ESTADO = BLOCKED
```

---

# 18. Dependencias

## Dependencias aprobadas

```text
[paquete]
[paquete]
```

## Dependencias prohibidas

```text
[paquete]
[paquete]
```

## Nuevas dependencias

Claude no debe instalar una nueva dependencia sin justificar:

```text
Nombre
Versión
Propósito
Por qué es necesaria
Por qué no puede resolverse con Angular/API existente
Impacto
```

Si la dependencia cambia la arquitectura:

```text
ESTADO = BLOCKED
```

---

# 19. Convenciones de código

Claude debe respetar:

```text
Naming
Estructura
TypeScript strictness
Standalone components
Signals
RxJS
Formatting
Linting
Testing
```

Las convenciones deben provenir de:

```text
AGENTS.md
DEC
TASK
```

No inventar convenciones incompatibles.

---

# 20. Testing requerido

## Unit tests

```text
[Prueba]
[Prueba]
```

## Integration tests

```text
[Prueba]
```

## Casos críticos

```text
[Escenario]
[Escenario]
```

## Criterio

Todos los tests existentes deben continuar funcionando.

Los nuevos tests deben cubrir los comportamientos definidos por la TASK.

---

# 21. Criterios de aceptación

La TASK se considera correctamente implementada únicamente cuando:

```text
AC-001:
[criterio verificable]

AC-002:
[criterio verificable]

AC-003:
[criterio verificable]
```

Cada criterio debe poder verificarse objetivamente.

Evitar criterios subjetivos como:

```text
"funciona bien"
"se ve correcto"
"está optimizado"
```

cuando puedan sustituirse por una condición verificable.

---

# 22. Validaciones obligatorias

Claude debe ejecutar, según corresponda:

```text
npm ci
npm test
npm run lint
npm run build
```

Y cualquier comando adicional definido por la TASK.

Registrar:

```text
Comando
Resultado
Errores
Correcciones realizadas
Resultado final
```

---

# 23. Verificación de regresión

Después de implementar:

```text
Verificar funcionalidad existente
Verificar rutas afectadas
Verificar tests existentes
Verificar build
Verificar lint
```

No declarar la TASK completada si existen regresiones no justificadas.

---

# 24. Control de cambios

Antes de finalizar:

```text
git status
git diff
```

Revisar:

```text
Archivos modificados
Archivos creados
Archivos eliminados
Dependencias modificadas
Configuración modificada
```

Confirmar que los cambios corresponden a la TASK.

---

# 25. Handoff específico para Claude

## Instrucciones de implementación

Claude debe:

1. leer primero los documentos de referencia;
2. inspeccionar el estado real del repositorio;
3. comparar el estado real contra este HANDOFF;
4. identificar discrepancias;
5. implementar únicamente el alcance aprobado;
6. ejecutar las validaciones;
7. corregir errores producidos por su implementación;
8. revisar el diff final;
9. reportar el resultado.

Claude NO debe:

- ampliar el alcance;
- modificar decisiones arquitectónicas;
- instalar dependencias arbitrarias;
- modificar Legacy sin autorización;
- eliminar validaciones;
- ocultar errores;
- asumir información faltante.

---

# 26. Discrepancias entre HANDOFF y repositorio

Si Claude encuentra una diferencia entre este documento y el estado real:

## Diferencia menor

Puede continuar si:

- no cambia la arquitectura;
- no afecta el alcance;
- no afecta seguridad;
- no contradice la TASK.

Debe documentarla.

## Diferencia significativa

Debe:

```text
ESTADO = BLOCKED
```

y reportar:

```text
Discrepancia
Evidencia
Impacto
Recomendación
```

No debe modificar el HANDOFF para hacer desaparecer la discrepancia.

---

# 27. Cambios realizados durante implementación

Esta sección debe ser completada por Claude.

```text
CHG-001:
[Descripción]

CHG-002:
[Descripción]
```

Cada cambio relevante debe indicar:

```text
Archivo
Cambio
Motivo
Relación con TASK
```

---

# 28. Desviaciones

Si la implementación no sigue exactamente el plan:

```text
DEV-001:
Descripción:
Motivo:
Impacto:
Autorización:
```

Si no existen:

```text
Ninguna.
```

No ocultar desviaciones.

---

# 29. Resultado de validación

Completar:

| Validación | Resultado | Evidencia |
|---|---|---|
| Instalación | PASS/FAIL | [evidencia] |
| Tests | PASS/FAIL | [evidencia] |
| Lint | PASS/FAIL | [evidencia] |
| Build | PASS/FAIL | [evidencia] |
| Criterios de aceptación | PASS/FAIL | [evidencia] |
| Regresión | PASS/FAIL | [evidencia] |
| Git diff | PASS/FAIL | [evidencia] |

---

# 30. Estado final

Utilizar exactamente uno:

```text
DRAFT
```

Gemini todavía está preparando el HANDOFF.

```text
APPROVED
```

El HANDOFF fue revisado y aprobado para implementación.

```text
IN_PROGRESS
```

Claude está ejecutando la implementación.

```text
COMPLETED
```

La implementación y validación terminaron correctamente.

```text
BLOCKED
```

Existe un problema que requiere intervención o decisión.

---

# 31. Revisión de Gemini

Después de que Claude termine, Gemini puede revisar:

```text
TASK
DEC
HANDOFF
git diff
archivos afectados
resultados de validación
```

La revisión debe determinar:

```text
¿La implementación cumple la TASK?
¿La implementación respeta la DEC?
¿Se respetó el alcance?
¿Se introdujeron dependencias innecesarias?
¿Existen problemas de arquitectura?
¿Existen problemas de seguridad?
¿Existen problemas de mantenibilidad?
¿Existen regresiones?
```

Resultado:

```text
REVIEW = APPROVED
```

o:

```text
REVIEW = CHANGES_REQUIRED
```

---

# 32. Cierre

Una TASK solo puede cerrarse cuando:

```text
TASK aprobada
AND
HANDOFF aprobado
AND
Implementación completada
AND
Validaciones PASS
AND
Criterios de aceptación PASS
AND
Sin desviaciones no autorizadas
AND
Revisión final completada
```

Entonces:

```text
HANDOFF STATUS = COMPLETED
TASK STATUS = COMPLETED
```

---

# 33. Regla de oro

Este documento existe para eliminar la dependencia de la conversación entre Gemini y Claude.

Todo lo necesario para implementar la TASK debe quedar registrado aquí o en los documentos de referencia.

La conversación puede desaparecer.

El HANDOFF debe permanecer.

Por lo tanto:

```text
CONVERSACIÓN
     ↓
conocimiento temporal

HANDOFF
     ↓
conocimiento persistente

REPOSITORIO
     ↓
fuente de verdad
```

---

# 34. Regla final

Si Claude no puede determinar con seguridad qué hacer a partir de:

```text
AGENTS.md
workflow.md
DEC
TASK
HANDOFF
estado real del repositorio
```

NO debe inventar una solución.

Debe marcar:

```text
BLOCKED
```

y proporcionar la información necesaria para que la decisión pueda ser tomada.